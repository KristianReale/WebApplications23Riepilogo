--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: riepilogo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA riepilogo;


ALTER SCHEMA riepilogo OWNER TO postgres;

--
-- Name: db_sequence; Type: SEQUENCE; Schema: riepilogo; Owner: postgres
--

CREATE SEQUENCE riepilogo.db_sequence
    START WITH 3
    INCREMENT BY 1
    MINVALUE 3
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riepilogo.db_sequence OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: recensioni; Type: TABLE; Schema: riepilogo; Owner: postgres
--

CREATE TABLE riepilogo.recensioni (
    id bigint NOT NULL,
    titolo character varying NOT NULL,
    testo character varying NOT NULL,
    numero_mi_piace integer DEFAULT 0 NOT NULL,
    numero_non_mi_piace integer DEFAULT 0 NOT NULL
);


ALTER TABLE riepilogo.recensioni OWNER TO postgres;

--
-- Name: utenti; Type: TABLE; Schema: riepilogo; Owner: postgres
--

CREATE TABLE riepilogo.utenti (
    username character varying NOT NULL,
    password character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL
);


ALTER TABLE riepilogo.utenti OWNER TO postgres;

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: riepilogo; Owner: postgres
--

COPY riepilogo.recensioni (id, titolo, testo, numero_mi_piace, numero_non_mi_piace) FROM stdin;
\.
COPY riepilogo.recensioni (id, titolo, testo, numero_mi_piace, numero_non_mi_piace) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: riepilogo; Owner: postgres
--

COPY riepilogo.utenti (username, password, nome, cognome) FROM stdin;
\.
COPY riepilogo.utenti (username, password, nome, cognome) FROM '$$PATH$$/3334.dat';

--
-- Name: db_sequence; Type: SEQUENCE SET; Schema: riepilogo; Owner: postgres
--

SELECT pg_catalog.setval('riepilogo.db_sequence', 3, false);


--
-- Name: recensioni recensioni_pk; Type: CONSTRAINT; Schema: riepilogo; Owner: postgres
--

ALTER TABLE ONLY riepilogo.recensioni
    ADD CONSTRAINT recensioni_pk PRIMARY KEY (id);


--
-- Name: utenti utenti_pk; Type: CONSTRAINT; Schema: riepilogo; Owner: postgres
--

ALTER TABLE ONLY riepilogo.utenti
    ADD CONSTRAINT utenti_pk PRIMARY KEY (username);


--
-- PostgreSQL database dump complete
--

